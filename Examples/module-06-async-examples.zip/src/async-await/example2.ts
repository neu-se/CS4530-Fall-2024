import { example } from './asyncExample';

async function main() {
  example(1);
  example(2);
  example(3);
  console.log('main finished\n');
}

main();
