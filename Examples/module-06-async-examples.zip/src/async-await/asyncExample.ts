export async function example(n:number) : Promise<void> {
  doThisNow(n);
  const p1 = somePromise();
  const response = await p1;
  doThisLater(n);
}

function doThisNow(n) { console.log('doThisNow', n); }
async function somePromise() { promiseNothing(); }
function doThisLater(n) { console.log('doThisLater', n); }

function promiseNothing() : Promise<void> {
  return new Promise((resolve, reject) => {
    resolve();
  });
}
