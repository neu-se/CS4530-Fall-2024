import { example } from './asyncExample';

function main() {
  console.log('starting main');
  example(1);
  console.log('main finished\n');
}

main();
