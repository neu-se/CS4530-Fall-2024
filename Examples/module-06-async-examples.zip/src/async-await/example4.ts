import { example } from './asyncExample';

async function forkJoin() : Promise<void> {
  console.log('forkJoin started');
  const promises = [example(1), example(2), example(3)];
  console.log(promises);
  await Promise.all(promises);
  console.log('forkJoin finished\n');
}

async function main() {
  forkJoin();
  console.log('main finished\n');
}

main();
