async function f(n): Promise<number> {
  console.log('entering f');
  return n;
}

function main() {
  const p = f(1);
  console.log('p =', p);
}

main();

export {};
