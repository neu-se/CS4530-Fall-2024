import makeRequest from './makeRequest';
import timeIt from './timeIt'

async function makeThreeSerialRequests() {
    await makeRequest(1);
    await makeRequest(2);
    await makeRequest(3);
    console.log("Three requests made; main thread finishes")
}

timeIt("main thread", makeThreeSerialRequests)